﻿namespace Services;



/// <summary>
/// Adder Client descriptor.
/// </summary>
public class AddDesc
{
    /// <summary>
    /// Adder ID.
    /// </summary>
    public int AdderId { get; set; }

    /// <summary>
    /// Add_number number.
    /// </summary>
    public int AdderNumber { get; set; }


}
/// <summary>
/// Remover Client descriptor.
/// </summary>
public class RemoveDesc
{
    /// <summary>
    /// Remover ID.
    /// </summary>
    public int RemoverId { get; set; }

    /// <summary>
    /// remove_number number.
    /// </summary>
    public int RemoverNumber { get; set; }


}



/// <summary>
/// Descriptor of watre level checker
/// </summary>
public class waterLevelchecker
{
    /// <summary>
    /// Indicates if the water level added or removed.
    /// </summary>
    public bool IsSuccess { get; set; }
    /// <summary>
    /// If not,indicates the reason
    /// </summary>
    public string failurereason { get; set; }


}


/// <summary>
/// Enum for water level state (lower and upper).
/// </summary>
public enum Waterleverstate : int
{
    upperlimit,
    lowerlimit
}


/// <summary>
/// Service contract.
/// </summary>
public interface IWaterLevelService
{

    /// <summary>
    /// Get the current UID for a water level state.
    /// </summary>
    /// <returns>Unique ID.</returns>
    int GetUniqueId();
    /// <summary>
    /// Get the current state of the water level.
    /// </summary>
    /// <returns>Returns the current state of the water level (upperlimit or lowerlimit)..</returns>
    Waterleverstate GetWaterleverstate();
    /// <summary>
    /// Get the current upper limit for the water level.
    /// </summary>
    /// <returns>the current upper limit for the water level.</returns>
    int getupperlimit();
    /// <summary>
    /// Get the current lower limit for the water level.
    /// </summary>
    /// <returns>the current lower limit for the water level..</returns>

    int getlowerlimit();
    /// <summary>
    /// Get the the current water level in the container.
    /// </summary>
    /// <returns>the current water level in the container.</returns>

    int getcurrentlimit();
    /// <summary>
    /// will add water using the provided AddDesc object
    /// </summary>
    /// <returns>returns a waterLevelchecker to indicate success or failure..</returns>
    waterLevelchecker addwater(AddDesc adddesc);
    /// <summary>
    /// will remove water using the provided RemoveDesc 
    /// </summary>
    /// <returns>returns a waterLevelchecker to indicate success or failure.</returns>
    waterLevelchecker removewater(RemoveDesc removedesc);

}
