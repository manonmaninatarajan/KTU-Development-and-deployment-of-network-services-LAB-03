﻿namespace Clients
{
    using System;
    using System.Text;
    using System.Threading;
    using RabbitMQ.Client;
    using RabbitMQ.Client.Events;
    using Newtonsoft.Json;
    using NLog;
    using Services;

    /// <summary>
    /// RPC style wrapper for the service.
    /// Static members are thread-safe, instance members are not.
    /// </summary>
    class removeContainerclient : IWaterLevelService
    {
        /// <summary>
        /// Name of the message exchange.
        /// </summary>
        private static readonly string ExchangeName = "T120B180.Container.Exchange";

        /// <summary>
        /// Name of the server queue.
        /// </summary>
        private static readonly string ServerQueueName = "T120B180.Container.ContainerService";

        /// <summary>
        /// Prefix for the name of the client queue.
        /// </summary>
        private static readonly string ClientQueueNamePrefix = "T120B180.Container.ContainerClient_";

        /// <summary>
        /// Logger for this class.
        /// </summary>
        private Logger log = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// Service client ID.
        /// </summary>
        public string ClientId { get; }

        /// <summary>
        /// Name of the client queue.
        /// </summary>
        private string ClientQueueName { get; }

        /// <summary>
        /// Connection to RabbitMQ message broker.
        /// </summary>
        private IConnection rmqConn;

        /// <summary>
        /// Communications channel to RabbitMQ message broker.
        /// </summary>
        private IModel rmqChann;

        /// <summary>
        /// Constructor.
        /// </summary>
        public removeContainerclient()
        {
            // Initialize properties
            ClientId = Guid.NewGuid().ToString();
            ClientQueueName = ClientQueueNamePrefix + ClientId;

            // Log client ID for easier traceability
            log.Info($"Client ID is '{ClientId}'.");

            // Connect to the RabbitMQ message broker
            var rmqConnFact = new ConnectionFactory();
            rmqConn = rmqConnFact.CreateConnection();

            // Get channel, configure exchange and queue
            rmqChann = rmqConn.CreateModel();

            rmqChann.ExchangeDeclare(exchange: ExchangeName, type: ExchangeType.Direct);
            rmqChann.QueueDeclare(queue: ClientQueueName, durable: false, exclusive: true, autoDelete: false, arguments: null);
            rmqChann.QueueBind(queue: ClientQueueName, exchange: ExchangeName, routingKey: ClientQueueName, arguments: null);
        }

        /// <summary>
        /// Generic method to call a remote operation on the server.
        /// </summary>
        private RESULT Call<RESULT>(
            string methodName,
            Func<string> requestDataProvider,
            Func<string, RESULT> resultDataExtractor
        )
        {
            if (methodName == null)
                throw new ArgumentException("Argument 'methodName' is null.");

            // Declare result storage
            RESULT result = default;

            var isResultReady = false;
            var resultReadySignal = new AutoResetEvent(false);

            var request = new RPCMessage()
            {
                Action = $"Call_{methodName}",
                Data = requestDataProvider != null ? requestDataProvider() : null
            };

            var requestProps = rmqChann.CreateBasicProperties();
            requestProps.CorrelationId = Guid.NewGuid().ToString();
            requestProps.ReplyTo = ClientQueueName;

            // Handle response if a resultDataExtractor is provided
            string consumerTag = null;
            if (resultDataExtractor != null)
            {
                Thread.MemoryBarrier();

                var consumer = new EventingBasicConsumer(rmqChann);
                consumer.Received += (channel, delivery) =>
                {
                    Thread.MemoryBarrier();

                    if (!isResultReady && (delivery.BasicProperties.CorrelationId == requestProps.CorrelationId))
                    {
                        var response = JsonConvert.DeserializeObject<RPCMessage>(Encoding.UTF8.GetString(delivery.Body.ToArray()));
                        if (response.Action == $"Result_{methodName}")
                        {
                            result = resultDataExtractor(response.Data);
                            isResultReady = true;
                            Thread.MemoryBarrier();
                            resultReadySignal.Set();
                        }
                        else
                        {
                            log.Info($"Unsupported type of RPC action '{request.Action}'. Ignoring the message.");
                        }
                    }
                };

                consumerTag = rmqChann.BasicConsume(ClientQueueName, true, consumer);
            }

            rmqChann.BasicPublish(
                exchange: ExchangeName,
                routingKey: ServerQueueName,
                basicProperties: requestProps,
                body: Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(request))
            );

            if (resultDataExtractor != null)
            {
                resultReadySignal.WaitOne();
                Thread.MemoryBarrier();
                rmqChann.BasicCancel(consumerTag);
                return result;
            }

            return default;
        }
        public int GetUniqueId()
        {
            var result = Call(nameof(GetUniqueId), null, (data) => JsonConvert.DeserializeAnonymousType(data, new { Value = 0 }).Value);
            return result;
        }
        /// <summary>
        /// Get next unique ID from the server.
        /// </summary>
        public int getupperlimit()
        {
            var result = Call(nameof(getupperlimit), null, (data) => JsonConvert.DeserializeAnonymousType(data, new { Value = 0 }).Value);
            return result;
        }

        /// <summary>
        /// Get lower limit from the server.
        /// </summary>
        public int getlowerlimit()
        {
            var result = Call(nameof(getlowerlimit), null, (data) => JsonConvert.DeserializeAnonymousType(data, new { Value = 0 }).Value);
            return result;
        }

        /// <summary>
        /// Get current water level.
        /// </summary>
        public int getcurrentlimit()
        {
            var result = Call(nameof(getcurrentlimit), null, (data) => JsonConvert.DeserializeAnonymousType(data, new { Value = 0 }).Value);
            return result;
        }
        public Waterleverstate GetWaterleverstate()
        {
            var result =
                Call(
                    nameof(GetWaterleverstate),
                    null,
                    (data) => JsonConvert.DeserializeAnonymousType(data, new { Value = Waterleverstate.upperlimit }).Value
                );
            return result;
        }
        /// <summary>
        /// Add water to the container.
        /// </summary>
        public waterLevelchecker addwater(AddDesc addDesc)
        {
            return Call(nameof(addwater), () => JsonConvert.SerializeObject(addDesc),
                (data) => JsonConvert.DeserializeObject<waterLevelchecker>(data));
        }
        public waterLevelchecker removewater(RemoveDesc removeDesc)
        {
            return Call(nameof(removewater), () => JsonConvert.SerializeObject(removeDesc),
                (data) => JsonConvert.DeserializeObject<waterLevelchecker>(data));
        }

    }
}

