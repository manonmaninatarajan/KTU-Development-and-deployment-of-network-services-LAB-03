﻿namespace Clients
{
    using NLog;
    using Services;
    using System;
    using System.Collections.Generic;
    using System.Threading;

    /// <summary>
    /// Client example.
    /// </summary>
    class RemoverClient
    {
        /// <summary>
        /// Logger for this class.
        /// </summary>
        private Logger mLog = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// Configures logging subsystem.
        /// </summary>
        private void ConfigureLogging()
        {
            var config = new NLog.Config.LoggingConfiguration();

            var console = new NLog.Targets.ConsoleTarget("console")
            {
                Layout = @"${date:format=HH\:mm\:ss}|${level}| ${message} ${exception}"
            };
            config.AddTarget(console);
            config.AddRuleForAllLevels(console);

            LogManager.Configuration = config;
        }

        /// <summary>
        /// Program body.
        /// </summary>
        private void Run()
        {
            // Configure logging
            ConfigureLogging();

            // Initialize random number generator
            var rnd = new Random();

            // Run everything in a loop to recover from connection errors
            while (true)
            {
                try
                {
                    // Connect to the server and get service client proxy
                    var container = new removeContainerclient();

                    // Initialize water container and add descriptor
                    var remover = new RemoveDesc();
                    while (true)
                    {
                        // var Remove = watercontainer.removewater(remover);

                        var currentLevel = container.getcurrentlimit(); // Fixed method name
                        var lowerLimit = container.getcurrentlimit();
                        var upperLimit = container.getupperlimit();
                        if (currentLevel > upperLimit)
                        {
                            //log identity data
                            //  mLog.Info($"Current water level: {currentlevel}. Lower limit: {lowerlimit}, Upper limit: {upperlimit}");
                            //  Console.Title = $"Current water level: {currentlevel}. Lower limit: {lowerlimit}, Upper limit: {upperlimit}";
                            if (currentLevel - upperLimit > 0)////if true and also checks the current limit is lower than the upper limit
                            {
                                remover.RemoverNumber = rnd.Next(1, currentLevel - upperLimit);//also ensures the remove element wont removes water below lower limit
                                var removeResult = container.removewater(remover);
                                mLog.Info($" {remover.RemoverNumber} units of water removed from the container, Current water level: {currentLevel}. Lower limit: {lowerLimit}, Upper limit: {upperLimit}");
                            }
                        }
                        Thread.Sleep(500 + rnd.Next(1500));//sleep thread for random amount of time to prevent spamming
                    }
                }
                catch (Exception e)
                {
                    // Log any exceptions
                    mLog.Warn(e, "Unhandled exception caught. Will restart main loop.");

                    // Prevent console spamming
                    Thread.Sleep(2000);
                }
            }
        }

        /// <summary>
        /// Program entry point.
        /// </summary>
        /// <param name="args">Command line arguments.</param>
        static void Main(string[] args)
        {
            var self = new RemoverClient();
            self.Run();
        }
    }


}