﻿namespace Clients
{
    using NLog;
    using Services;
    using System;
    using System.Collections.Generic;
    using System.Threading;

    /// <summary>
    /// Client example.
    /// </summary>
    class AdderClient
    {
                /// <summary>
        /// Logger for this class.
        /// </summary>
        private Logger mLog = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// Configures logging subsystem.
        /// </summary>
        private void ConfigureLogging()
        {
            var config = new NLog.Config.LoggingConfiguration();

            var console = new NLog.Targets.ConsoleTarget("console")
            {
                Layout = @"${date:format=HH\:mm\:ss}|${level}| ${message} ${exception}"
            };
            config.AddTarget(console);
            config.AddRuleForAllLevels(console);

            LogManager.Configuration = config;
        }

        /// <summary>
        /// Program body.
        /// </summary>
        private void Run()
        {
            // Configure logging
            ConfigureLogging();

            // Initialize random number generator
            var rnd = new Random();

            // Run everything in a loop to recover from connection errors
            while (true)
            {
                try
                {
                    // Connect to the server and get service client proxy
                    var container = new addContainerclient();

                    // Initialize water container and add descriptor
                    var adder = new AddDesc();
                    while (true)
                    {
                        // Getting water container's current level, limits, etc.
                        var currentLevel = container.getcurrentlimit();
                        var lowerLimit = container.getlowerlimit();
                        var upperLimit = container.getupperlimit();

                        if (currentLevel < lowerLimit)
                        {
                            if (lowerLimit - currentLevel > 0)
                            {
                                adder.AdderNumber = rnd.Next(1, lowerLimit - currentLevel);

                                // Try to add water and check the response
                                var addResult = container.addwater(adder);
                              
                                 mLog.Info($"{adder.AdderNumber} units of water added successfully. Current water level: {currentLevel}. Lower limit: {lowerLimit}, Upper limit: {upperLimit}");
                                Thread.Sleep(500 + rnd.Next(1500));//sleep thread for random amount of time to prevent spamming

                            }
                        }

                    }
                }
                catch (Exception e)
                {
                    // Log any exceptions
                    mLog.Warn(e, "Unhandled exception caught. Will restart main loop.");

                    // Prevent console spamming
                    Thread.Sleep(2000);
                }
            }
        }

        /// <summary>
        /// Program entry point.
        /// </summary>
        /// <param name="args">Command line arguments.</param>
        static void Main(string[] args)
        {
            var self = new AdderClient();
            self.Run();
        }
    }

    
}
